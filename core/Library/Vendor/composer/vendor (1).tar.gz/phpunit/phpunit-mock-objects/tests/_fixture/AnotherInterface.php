<?php
interface AnotherInterface
{
    public function doSomethingElse();
}
