<?php
class StringableClass
{
    public function __toString()
    {
        return '12345';
    }
}
